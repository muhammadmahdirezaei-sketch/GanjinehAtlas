گنجینه اطلس — نسخه بهینه‌شده برای شروع سئو
===========================================
این نسخه ظاهر قبلی صفحه را حفظ می‌کند و عنوان، توضیحات متا و داده ساختاریافته برند را بهبود می‌دهد.

مهم:
- این فایل‌ها سایت را منتشر نمی‌کنند و رتبه اول گوگل را تضمین نمی‌کنند.
- ابتدا سایت را روی GitHub Pages منتشر کنید تا آدرس عمومی آن مشخص شود.
- بعد از مشخص شدن آدرس نهایی، sitemap.xml و نشانی canonical را با URL واقعی تنظیم کنید؛ آدرس ساختگی وارد نکنید.
- سایت را در Google Search Console ثبت و مالکیت را تأیید کنید.
- در Search Console از URL Inspection برای درخواست ایندکس صفحه اصلی استفاده کنید.
- لینک سایت را در کانال تلگرام و پروفایل‌های رسمی خود منتشر کنید تا افراد و موتورهای جست‌وجو راحت‌تر آن را پیدا کنند.
- برای شروع، روی عبارت برند «گنجینه اطلس» و «Ganjineh Atlas» تمرکز کنید. رتبه برای عبارت‌های عمومی مثل «طلا» رقابت بسیار بیشتری دارد.

انتشار رایگان:
1) در github.com حساب بسازید.
2) یک repository عمومی بسازید.
3) index.html و robots.txt را در ریشه مخزن بارگذاری کنید.
4) Settings > Pages > Deploy from a branch > main > /(root) > Save.
5) پس از فعال شدن سایت، URL عمومی را در Search Console ثبت کنید.

منابع رسمی:
Google SEO Starter Guide: https://developers.google.com/search/docs/fundamentals/seo-starter-guide
Google Search Console: https://search.google.com/search-console/
GitHub Pages: https://pages.github.com/
